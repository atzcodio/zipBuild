import * as ProductCmp from "./static/js/components/productinfo.es.js"; 
window.LowcodePlatform.registerComponent("ProductInfo", ProductCmp);