const C = {};
function _e(e) {
  Object.assign(C, e);
}
let be = null;
function dt(e) {
  return be || (be = (async () => {
    const g = (e == null ? void 0 : e()) ?? null;
    if (g != null && g.React)
      Object.assign(C, {
        React: g.React,
        useState: g.React.useState,
        useEffect: g.React.useEffect,
        useMemo: g.React.useMemo,
        useRef: g.React.useRef,
        useCallback: g.React.useCallback
      });
    else {
      const f = await import("react");
      Object.assign(C, {
        React: f.default || f,
        useState: f.useState,
        useEffect: f.useEffect,
        useMemo: f.useMemo,
        useRef: f.useRef,
        useCallback: f.useCallback
      });
    }
    if (g != null && g.antd)
      Object.assign(C, {
        Drawer: g.antd.Drawer,
        Popover: g.antd.Popover
      });
    else {
      const { Drawer: f, Popover: q } = await import("antd");
      Object.assign(C, { Drawer: f, Popover: q });
    }
    if (g != null && g.icons && Object.assign(C, g.icons), !C.ArrowUpOutlined) {
      const f = await import("@ant-design/icons");
      Object.assign(C, {
        ArrowUpOutlined: f.ArrowUpOutlined,
        ArrowDownOutlined: f.ArrowDownOutlined,
        PlusOutlined: f.PlusOutlined
      });
    }
    if (!C.AiOutlineCaretDown) {
      const f = await import("react-icons/ai");
      Object.assign(C, {
        AiOutlineCaretDown: f.AiOutlineCaretDown,
        AiOutlineCaretUp: f.AiOutlineCaretUp,
        AiOutlineCompress: f.AiOutlineCompress
      });
    }
    if (!C.FaFilter) {
      const f = await import("react-icons/fa");
      Object.assign(C, {
        FaFilter: f.FaFilter
      });
    }
    if (!C.TableList) {
      const { FixedSizeList: f } = await import("react-window");
      Object.assign(C, {
        TableList: f
      });
    }
    if (!C.AutoSizer) {
      const f = await import("react-virtualized-auto-sizer");
      Object.assign(C, {
        AutoSizer: f.default || f
      });
    }
    return C;
  })(), be);
}
const ze = (e) => ({
  ...e,
  grid: {
    desktop: {
      width: 12,
      // Override width for desktop
      height: 30
      // Keep height the same or adjust as needed
    },
    mobile: {
      width: 24,
      // Keep the same or adjust for mobile
      height: 20
      // Keep the same or adjust as needed
    }
  },
  resizable: {
    width: !0,
    height: !0
  }
}), Pe = (e, g) => [
  {
    type: e.GROUP("basic"),
    width: 24,
    collaseOpen: !0,
    elements: [
      {
        label: "Name",
        name: "_name",
        type: e.TEXT(""),
        showLabel: !0,
        width: 24
      }
    ]
  },
  {
    type: e.GROUP("data"),
    // Grouping for basic properties
    elements: [
      {
        label: "Data",
        name: "data",
        type: e.TEXT(),
        width: 24,
        showFx: !0,
        onlyFx: !0,
        fx: '[{"name":"John Doe","age":28,"email":"john@example.com","id":1},{"name":"Jane Smith","age":34,"email":"jane@example.com","id":2},{"name":"Mike Johnson","age":45,"email":"mike@example.com","id":3}]'
      },
      {
        label: "Default Selected",
        name: "defaultSelected",
        type: e.SELECT(["none", "first", "last", "filter"], "none"),
        width: 12
      },
      {
        label: "Default Filter",
        name: "defaultSelectedFilter",
        type: e.JSON({}),
        width: 12,
        showFx: !0,
        fx: '{"columnName": "value to match"}'
      },
      {
        label: "selection_type",
        name: "selection_type",
        type: e.SELECT(["single", "multiple"], "single"),
        width: 24
      }
    ]
  },
  {
    type: e.GROUP("columns"),
    width: 24,
    collaseOpen: !0,
    elements: [
      {
        label: "primary_key",
        name: "primary_key",
        type: e.SELECT([], ""),
        width: 24
      },
      {
        label: "Column List",
        name: "columns",
        type: e.REPEATBLOCK({
          columnName: e.TEXT(""),
          columnType: e.SELECT(["Text", "Number", "Boolean", "Url", "Email", "Json", "MultiSelect", "SingleSelect"], "Text")
        }, [], {
          add: !1,
          remove: !1,
          height: "250px",
          sortable: !0,
          showOrder: !0
        }),
        width: 24
      }
    ]
  },
  {
    type: e.GROUP("style"),
    width: 24,
    collaseOpen: !0,
    elements: [
      {
        label: "Header Background",
        name: "header_bg",
        type: e.COLOR("#f7f7f7"),
        showLabel: !0,
        width: 24,
        showFx: !0
      },
      {
        label: "Header Font Color",
        name: "header_font_color",
        type: e.COLOR("#ffffff"),
        showLabel: !0,
        width: 24,
        showFx: !0
      },
      {
        label: "Body Backgorund",
        name: "body_bg",
        type: e.COLOR("#d9e3f0"),
        showLabel: !0,
        width: 24,
        showFx: !0
      },
      {
        label: "Body Font Color",
        name: "body_font_color",
        type: e.COLOR("#555555"),
        showLabel: !0,
        width: 24,
        showFx: !0
      },
      {
        label: "Check Color",
        name: "checkbox_accent_col",
        type: e.COLOR("#b0b0b0"),
        showLabel: !0,
        width: 24,
        showFx: !0
      },
      {
        label: "Check Border Color",
        name: "checkboxBorderColor",
        type: e.COLOR("#b0b0b0"),
        showLabel: !0,
        width: 24,
        showFx: !0
      },
      {
        label: "Selection Background",
        name: "selectionBg",
        type: e.COLOR("#bae0ff"),
        showLabel: !0,
        width: 24,
        showFx: !0
      },
      {
        label: "Border",
        name: "border",
        type: e.TEXT("1px solid #e1e1e1"),
        showLabel: !0,
        width: 24,
        themePropertyName: g.backgroundColor,
        showFx: !0
      },
      {
        label: "Border Radius",
        name: "border_radius",
        type: e.BORDERRADIUS(["5px", "5px", "5px", "5px"]),
        showLabel: !0,
        width: 24
      },
      {
        label: "Margin",
        name: "margin",
        type: e.SPACING(["5px", "5px", "5px", "5px"]),
        showLabel: !0,
        width: 24
      }
    ]
  }
], ut = (e) => ({
  border: e.borderColor
});
function mt(e, g, f, q) {
  const K = Pe(e, g);
  return {
    name: "Table",
    EditProperties: K,
    Configuration: ze(f),
    ThemeMapping: ut(g),
    defaultProps: q(K)
  };
}
const pt = (e) => {
  const { React: g } = e;
  if (!g) return { FilterComponent: () => null, FilterGroup: () => null, RowComponent: () => null };
  const f = g.useState, q = g.useRef, K = g.useEffect, ee = () => C, Se = ({
    columns: b,
    tableData: u,
    originalData: L,
    setTableData: v
  }) => {
    const { Drawer: D, Popover: X, PlusOutlined: te, AiOutlineCaretDown: se, AiOutlineCaretUp: re, AiOutlineCompress: G, FaFilter: le, TableList: F, AutoSizer: ne } = ee(), [_, j] = f(u);
    let $ = b[0].columnType;
    const [o, a] = f([
      {
        id: "group1",
        filters: [{ column: $, operator: "", value: "" }],
        logicalOperator: "And",
        subGroups: []
      }
    ]), [n, m] = f([
      {
        id: "group1",
        filters: [{ column: $, operator: "", value: "" }],
        logicalOperator: "And",
        subGroups: []
      }
    ]), i = (A, s) => !s || s.length === 0 ? A : s.reduce((r, B) => k(r, B), A), k = (A, s) => {
      let r = [...A];
      return s.filters.length > 0 && (s.logicalOperator === "And" ? r = r.filter(
        (B) => s.filters.every((p) => O(B, p))
      ) : s.logicalOperator === "Or" && (r = r.filter(
        (B) => s.filters.some((p) => O(B, p))
      ))), s.subGroups && s.subGroups.length > 0 && (s.logicalOperator === "And" ? r = s.subGroups.reduce(
        (B, p) => k(B, p),
        r
      ) : s.logicalOperator === "Or" && (r = s.subGroups.map(
        (p) => k(A, p)
      ).flat())), r;
    }, O = (A, s) => {
      let r = A[s.column];
      if (!s.operator || !s.column) return !0;
      const { column: B, operator: p, value: E } = s;
      switch (p) {
        case "includes":
          return String(r).includes(String(E));
        case "notIncludes":
          return !String(r).includes(String(E));
        case "is":
          return String(r) === String(E);
        case "isNot":
          return String(r) !== String(E);
        case "isEmpty":
          return r == null || r === "";
        case "isNotEmpty":
          return r != null && r !== "";
        case "equalTo":
          return Number(r) === Number(E);
        case "notEqualTo":
          return Number(r) !== Number(E);
        case "lessThan":
          return Number(r) < Number(E);
        case "greaterThan":
          return Number(r) > Number(E);
        case "lessThanEqual":
          return Number(r) <= Number(E);
        case "greaterThanEqual":
          return Number(r) >= Number(E);
        case "between":
          let xe = E.split(",")[0], ce = E.split(",")[1];
          return Number(r) >= Number(xe) && Number(r) <= Number(ce);
        case "true":
          return r === !0;
        case "false":
          return r === !1;
        case "is":
          return new Date(r).getTime() === new Date(E).getTime();
        case "isNot":
          return new Date(r).getTime() !== new Date(E).getTime();
        case "isBefore":
          return new Date(r).getTime() < new Date(E).getTime();
        case "isAfter":
          return new Date(r).getTime() > new Date(E).getTime();
        case "isEmpty":
          return r == null;
        case "isNotEmpty":
          return r != null;
        default:
          return !1;
      }
    }, W = () => {
      console.log("group filter", o);
      let A = i(L, o);
      v(A);
    }, N = () => {
      a([
        {
          id: "group1",
          filters: [{ column: $, operator: "", value: "" }],
          logicalOperator: "And",
          subGroups: []
        }
      ]), v(L);
    };
    return /* @__PURE__ */ e.React.createElement(
      "div",
      {
        className: "border-none p-0 rounded-md w-full bg-white",
        style: { width: "650px" }
      },
      /* @__PURE__ */ e.React.createElement(
        V,
        {
          filterGroups: o,
          setFilterGroups: a,
          firstColumn: $,
          columns: b,
          originalFilterGroup: n
        }
      ),
      /* @__PURE__ */ e.React.createElement("div", { className: "flex justify-end mt-4 gap-2" }, /* @__PURE__ */ e.React.createElement(
        "button",
        {
          onClick: W,
          className: "px-4 py-1 bg-blue-500 text-sm text-white rounded-md hover:bg-blue-600 transition"
        },
        "Apply Filter"
      ), /* @__PURE__ */ e.React.createElement(
        "button",
        {
          onClick: N,
          className: "px-4 py-1 bg-blue-500 text-sm text-white rounded-md hover:bg-red-400 transition"
        },
        "Reset Filter"
      ))
    );
  }, oe = {
    Text: [
      { label: "includes", name: "includes" },
      { label: "does not include", name: "notIncludes" },
      { label: "is", name: "is" },
      { label: "is not", name: "isNot" },
      { label: "is empty", name: "isEmpty" },
      { label: "is not empty", name: "isNotEmpty" }
    ],
    Number: [
      { label: "=", name: "equalTo" },
      { label: "!=", name: "notEqualTo" },
      { label: "<", name: "lessThan" },
      { label: ">", name: "greaterThan" },
      { label: "<=", name: "lessThanEqual" },
      { label: ">=", name: "greaterThanEqual" },
      { label: "between", name: "between" },
      { label: "is empty", name: "isEmpty" },
      { label: "is not empty", name: "isNotEmpty" }
    ],
    Boolean: [
      { label: "is true", name: "true" },
      { label: "is false", name: "false" }
    ],
    date: [
      { label: "is", name: "is" },
      { label: "is not", name: "isNot" },
      { label: "is before", name: "isBefore" },
      { label: "is after", name: "isAfter" },
      { label: "is empty", name: "isEmpty" },
      { label: "is not empty", name: "isNotEmpty" }
    ]
  }, V = function({ filterGroups: b, setFilterGroups: u, firstColumn: L, columns: v, originalFilterGroup: D, parentGroupId: X, parentLogicalOperator: te }) {
    const { Popover: se, PlusOutlined: re } = ee(), G = (o, a, n, m, i) => {
      var W, N, A, s;
      const k = [...D], O = F(k, o);
      if (O) {
        if (i) {
          const r = ((W = O.filters[a].value) == null ? void 0 : W.split(",")) || ["", ""];
          n === "from" ? r[0] = m : n === "to" && (r[1] = m, console.log("between in handle", r)), O.filters[a].value = r.join(",");
        } else
          O.filters[a][n] = m;
        if (n === "column") {
          let r = ((N = v[m]) == null ? void 0 : N.columnType) || "string";
          (r === "Url" || r === "Email" || r === "Url" || r === "Json") && (r = "Text"), O.filters[a].operator = ((s = (A = oe[r]) == null ? void 0 : A[0]) == null ? void 0 : s.name) || "", O.filters[a].value = "";
        }
        u(k);
      }
    }, le = (o, a) => {
      const n = [...D], m = F(n, o);
      m && (m.logicalOperator = a, u(n));
    }, F = (o, a) => {
      for (const n of o) {
        if (n.id === a) return n;
        if (n.subGroups) {
          const m = F(n.subGroups, a);
          if (m) return m;
        }
      }
      return null;
    }, ne = (o) => {
      var m;
      const n = { id: `group${Date.now()}`, filters: [{ column: L, operator: "", value: "" }], logicalOperator: "And", subGroups: [] };
      if (o) {
        const i = [...D], k = F(i, o);
        k && ((m = k.subGroups) == null || m.push(n)), u(i);
      } else
        console.log("filterGroups not parentGroup", [...b, n]), u([...b, n]);
      console.log("filterGroups updated", b);
    }, _ = (o) => {
      var a;
      if (X) {
        let n = [...D];
        const m = F(n, X);
        m && (m.subGroups = (a = m.subGroups) == null ? void 0 : a.filter((i) => i.id !== o)), u(n);
      } else
        u(b.filter((n) => n.id !== o));
    }, j = (o) => {
      var i;
      const a = { column: "", operator: "", value: "" }, n = [...D], m = F(n, o);
      m && ((i = m == null ? void 0 : m.filters) == null || i.push(a)), u(n);
    }, $ = (o, a) => {
      let n = [...D], m = F(n, o);
      m && m.filters.splice(a, 1), u(n);
    };
    return /* @__PURE__ */ e.React.createElement("div", null, b.map((o) => /* @__PURE__ */ e.React.createElement("div", { key: o.id, className: " mb-4 p-4" }, /* @__PURE__ */ e.React.createElement("div", { className: "flex justify-between mb-2" }, /* @__PURE__ */ e.React.createElement("div", { className: "flex items-center gap-2" }, /* @__PURE__ */ e.React.createElement("div", { className: "flex items-center gap-0 mt-2 border rounded-sm" }, /* @__PURE__ */ e.React.createElement(
      "button",
      {
        onClick: () => le(o.id, o.logicalOperator === "And" ? "Or" : "And"),
        className: `px-2 text-xs  py-1 ${o.logicalOperator === "And" ? "bg-blue-500 text-white" : "bg-gray-100 text-gray-600"}`
      },
      "AND"
    ), /* @__PURE__ */ e.React.createElement(
      "button",
      {
        onClick: () => le(o.id, o.logicalOperator === "Or" ? "And" : "Or"),
        className: `px-2 text-xs py-1 ${o.logicalOperator === "Or" ? "bg-blue-500 text-white" : "bg-gray-100 text-gray-600"}`
      },
      "OR"
    )), /* @__PURE__ */ e.React.createElement(
      se,
      {
        trigger: "click",
        content: /* @__PURE__ */ e.React.createElement("div", { className: "flex flex-col" }, /* @__PURE__ */ e.React.createElement(
          "button",
          {
            className: "text-left px-4 py-2 hover:bg-gray-100 w-full",
            onClick: () => j(o.id)
          },
          "Add Filter"
        ), /* @__PURE__ */ e.React.createElement(
          "button",
          {
            className: "text-left px-4 py-2 hover:bg-gray-100 w-full",
            onClick: () => ne(o.id)
          },
          "Add Filter Group"
        ))
      },
      /* @__PURE__ */ e.React.createElement("span", { className: "m-4 ml-0 cursor-pointer " }, /* @__PURE__ */ e.React.createElement(re, { className: "mt-2 ml-1 text-gray-400", style: { fontSize: "25px" } }))
    )), /* @__PURE__ */ e.React.createElement("button", { onClick: () => _(o.id), className: "text-gray-600 font-semibold" }, "✕")), o.filters.map((a, n) => {
      var m, i, k, O, W, N, A;
      return /* @__PURE__ */ e.React.createElement("div", { key: n, className: "flex items-center gap-2 mb-2", style: { marginLeft: `${n === 0 ? `${o.logicalOperator === "And" ? "33px" : "23px"}` : 0}` } }, n > 0 && /* @__PURE__ */ e.React.createElement("div", null, /* @__PURE__ */ e.React.createElement("h1", null, o.logicalOperator)), /* @__PURE__ */ e.React.createElement("div", { className: "flex-1 ", style: { maxWidth: "30%" } }, /* @__PURE__ */ e.React.createElement(
        "select",
        {
          style: {
            appearance: "none",
            WebkitAppearance: "none",
            MozAppearance: "none",
            backgroundColor: "white",
            border: "1px solid #E1E1E1",
            padding: "4px 23px 4px 10px",
            fontSize: "14px",
            color: "#4B5563",
            borderRadius: "4px",
            backgroundImage: `url("data:image/svg+xml;utf8,<svg fill='gray' height='16' viewBox='0 0 24 24' width='16' xmlns='http://www.w3.org/2000/svg'><path d='M7 10l5 5 5-5z'/></svg>")`,
            backgroundRepeat: "no-repeat",
            backgroundPosition: "right 0px center",
            backgroundSize: "27px",
            cursor: "pointer"
          },
          value: a.column,
          onChange: (s) => G(o.id, n, "column", s.target.value),
          className: "border rounded px-3 py-1 w-full text-gray-600"
        },
        /* @__PURE__ */ e.React.createElement("option", { value: "" }, "Select Column"),
        Object.keys(v).map((s) => /* @__PURE__ */ e.React.createElement("option", { key: s, value: v[s].columnName }, v[s].columnName))
      )), /* @__PURE__ */ e.React.createElement("div", { className: "flex-1", style: { maxWidth: "30%" } }, a.column && /* @__PURE__ */ e.React.createElement(
        "select",
        {
          style: {
            appearance: "none",
            WebkitAppearance: "none",
            MozAppearance: "none",
            backgroundColor: "white",
            border: "1px solid #E1E1E1",
            padding: "4px 23px 4px 10px",
            fontSize: "14px",
            color: "#4B5563",
            borderRadius: "4px",
            backgroundImage: `url("data:image/svg+xml;utf8,<svg fill='gray' height='16' viewBox='0 0 24 24' width='16' xmlns='http://www.w3.org/2000/svg'><path d='M7 10l5 5 5-5z'/></svg>")`,
            backgroundRepeat: "no-repeat",
            backgroundPosition: "right 0px center",
            backgroundSize: "27px",
            cursor: "pointer"
          },
          value: a.operator,
          onChange: (s) => G(o.id, n, "operator", s.target.value),
          className: "border rounded px-3 py-1 w-full text-gray-600"
        },
        (i = oe[(m = v.find((s) => s.columnName === a.column)) == null ? void 0 : m.columnType]) == null ? void 0 : i.map((s) => /* @__PURE__ */ e.React.createElement("option", { key: s.name, value: s.name }, s.label))
      )), /* @__PURE__ */ e.React.createElement("div", { className: "flex-1 shrink-1", style: { maxWidth: "32%" } }, a.column && ((k = v.find((s) => s.columnName === a.column)) == null ? void 0 : k.columnType) !== "Boolean" && (a.operator === "between" ? /* @__PURE__ */ e.React.createElement("div", { className: "flex gap-2 " }, /* @__PURE__ */ e.React.createElement(
        "input",
        {
          style: {
            maxWidth: "50%",
            border: "1px solid #E1E1E1",
            padding: "4px",
            fontSize: "14px",
            color: "#4B5563",
            borderRadius: "4px",
            cursor: "pointer"
          },
          type: "number",
          placeholder: "from",
          value: ((O = a.value) == null ? void 0 : O.split(",")[0]) || "",
          onChange: (s) => G(o.id, n, "from", s.target.value, !0)
        }
      ), /* @__PURE__ */ e.React.createElement(
        "input",
        {
          style: {
            maxWidth: "50%",
            border: "1px solid #E1E1E1",
            padding: "4px",
            fontSize: "14px",
            color: "#4B5563",
            borderRadius: "4px",
            cursor: "pointer"
          },
          type: "number",
          placeholder: "to",
          value: ((W = a.value) == null ? void 0 : W.split(",")[1]) || "",
          onChange: (s) => G(o.id, n, "to", s.target.value, !0),
          className: "border rounded px-3 py-1 w-1/2 text-gray-600"
        }
      )) : /* @__PURE__ */ e.React.createElement(
        "input",
        {
          style: {
            maxWidth: "100%",
            // appearance: "none",
            // WebkitAppearance: "none",
            // MozAppearance: "none",
            // backgroundColor: "white",
            border: "1px solid #E1E1E1",
            padding: "4px",
            fontSize: "14px",
            color: "#4B5563",
            borderRadius: "4px",
            cursor: "pointer"
          },
          type: ((N = v[a.column]) == null ? void 0 : N.columnType) === "Date" ? "date" : "text",
          value: a.value || "",
          onChange: (s) => G(o.id, n, "value", s.target.value),
          placeholder: ((A = v[a.column]) == null ? void 0 : A.columnType) === "Date" ? "MMM D, YYYY" : "Filter Value"
        }
      ))), /* @__PURE__ */ e.React.createElement("button", { onClick: () => $(o.id, n), className: "text-gray-600 ml-auto ", style: { fontSize: "medium" } }, "✕"));
    }), (o == null ? void 0 : o.subGroups.length) > 0 && /* @__PURE__ */ e.React.createElement(
      "div",
      {
        className: "relative w-full  rounded-md border",
        style: { backgroundColor: "#f9f9f9", borderLeft: "4px solid #007bff", overflow: "auto" }
      },
      /* @__PURE__ */ e.React.createElement("div", { className: "absolute left-2 top-1/2 transform -translate-y-1/2 font-bold text-sm" }, o.logicalOperator),
      /* @__PURE__ */ e.React.createElement(
        "div",
        {
          className: "ml-[50px] overflow-auto relative",
          style: { width: "calc(100% - 50px)", maxHeight: "200px" }
        },
        /* @__PURE__ */ e.React.createElement(
          "div",
          {
            className: "overflow-y-auto p-2 bg-white rounded-md shadow-md",
            style: { maxHeight: "200px", paddingBottom: "10px", width: "534px" }
          },
          /* @__PURE__ */ e.React.createElement(
            V,
            {
              filterGroups: o.subGroups,
              setFilterGroups: u,
              firstColumn: L,
              columns: v,
              originalFilterGroup: D,
              parentGroupId: o.id,
              parentLogicalOperator: o.logicalOperator
            }
          )
        )
      )
    ))));
  }, he = g.memo(({
    row: b,
    index: u,
    isSelected: L,
    columns: v,
    columnsState: D,
    selectionType: X,
    handleRowClick: te,
    checkboxBorderColor: se,
    checkboxAccentCol: re,
    selectionBg: G,
    renderCell: le,
    showDrawer: F,
    style: ne
  }) => {
    const { AiOutlineCompress: _, Popover: j } = ee();
    let $ = q(!1);
    const o = (a) => /* @__PURE__ */ e.React.createElement("div", { style: { maxWidth: "300px", maxHeight: "200px", overflow: "auto" } }, /* @__PURE__ */ e.React.createElement("pre", null, a), " ");
    return K(() => {
      $.current || ($.current = !0);
    }, [v]), /* @__PURE__ */ e.React.createElement(
      "tr",
      {
        key: b.key || u,
        onClick: (a) => {
          a.target.type !== "checkbox" && te(b, u);
        },
        style: {
          ...ne,
          backgroundColor: L ? G : "transparent",
          cursor: "pointer",
          borderBottom: "1px solid #E1E1E1",
          maxHeight: "50px",
          overflow: "hidden",
          display: "flex",
          flexDirection: "row",
          alignItems: "center"
        }
      },
      X === "multiple" && /* @__PURE__ */ e.React.createElement("td", { style: { padding: "15px", alignItems: "center" } }, /* @__PURE__ */ e.React.createElement("div", null, /* @__PURE__ */ e.React.createElement(
        "input",
        {
          type: "checkbox",
          checked: L,
          onChange: (a) => {
            a.stopPropagation(), te(b, u);
          },
          style: {
            appearance: "none",
            width: "18px",
            height: "18px",
            borderRadius: "6px",
            border: `1px solid ${se}`,
            backgroundColor: L ? re : "transparent",
            transition: "all 0.2s ease-in-out",
            display: "flex",
            alignItems: "center",
            justifyContent: "center",
            position: "static"
          }
        }
      ))),
      /* @__PURE__ */ e.React.createElement("td", { style: { padding: "5px", maxHeight: "50px", minWidth: "110px", maxWidth: "110px", textAlign: "center", alignItems: "center", position: "relative" } }, /* @__PURE__ */ e.React.createElement("div", { style: { display: "flex", justifyContent: "center", alignItems: "center", height: "100%", position: "absolute", top: "50%", left: "50%", transform: "translate(-50%,-50%)" } }, /* @__PURE__ */ e.React.createElement(
        "a",
        {
          onClick: (a) => {
            a.stopPropagation(), F(b);
          },
          className: "text-black no-underline transition duration-200 ease-in-out hover:text-blue-600"
        },
        /* @__PURE__ */ e.React.createElement(_, { style: { fontSize: "20px" } })
      ))),
      D.map((a) => {
        const n = v.find((k) => k.columnName === a.accessor);
        if (!n)
          return console.warn(`Column not found for columnName: ${a.accessor}`), null;
        const m = `${b.key}-${a.accessor}`;
        let i = le(b[a.accessor], n.columnType, m);
        return /* @__PURE__ */ e.React.createElement("td", { key: m, className: "w-full", style: { padding: "5px 15px", minWidth: "160px", maxWidth: "160px", maxHeight: "50px", alignItems: "center", position: "relative" } }, n.columnType === "MultiSelect" && Array.isArray(i) ? /* @__PURE__ */ e.React.createElement("div", { style: { display: "flex", flexWrap: "wrap", gap: "5px", alignItems: "center", position: "absolute", top: "50%", left: "50%", transform: "translate(-50%,-50%)" } }, i == null ? void 0 : i.slice(0, 2).map((k, O) => /* @__PURE__ */ e.React.createElement("span", { key: O, style: {
          backgroundColor: "#E6F7FF",
          padding: "5px 10px",
          borderRadius: "4px",
          fontSize: "12px",
          color: "#333",
          border: "1px solid rgba(0,0,0,0.1)"
        } }, (k == null ? void 0 : k.title) ?? "N/A")), (i == null ? void 0 : i.length) > 2 && /* @__PURE__ */ e.React.createElement(
          j,
          {
            content: /* @__PURE__ */ e.React.createElement("div", { style: {
              display: "flex",
              flexDirection: "column",
              gap: "4px",
              maxWidth: "200px",
              padding: "8px"
            } }, i == null ? void 0 : i.slice(2).map((k, O) => /* @__PURE__ */ e.React.createElement("span", { key: O, style: {
              backgroundColor: "#FFF7E6",
              padding: "4px 8px",
              borderRadius: "6px",
              fontSize: "12px",
              color: "#333",
              border: "1px solid rgba(0,0,0,0.1)"
            } }, (k == null ? void 0 : k.title) ?? "N/A"))),
            trigger: "hover",
            placement: "right"
          },
          /* @__PURE__ */ e.React.createElement("span", { style: {
            cursor: "pointer",
            color: "#888",
            fontSize: "12px",
            paddingLeft: "5px"
          } }, "+", i.length - 2, " more")
        )) : n.columnType === "Json" || n.columnType === "Text" ? /* @__PURE__ */ e.React.createElement(
          j,
          {
            content: () => o(i),
            trigger: "hover",
            placement: "right"
          },
          /* @__PURE__ */ e.React.createElement("span", { style: { cursor: "pointer", color: "#898585" } }, String(i).length > 15 ? String(i).substring(0, 15) + "..." : String(i))
        ) : i);
      })
    );
  }, (b, u) => !(b.isSelected !== u.isSelected || b.selectionType !== u.selectionType || b.checkboxAccentCol !== u.checkboxAccentCol || b.checkboxBorderColor !== u.checkboxBorderColor || b.selectionBg !== u.selectionBg || JSON.stringify(b.row) !== JSON.stringify(u.row) || JSON.stringify(b.columns) !== JSON.stringify(u.columns) || JSON.stringify(b.columnsState) !== JSON.stringify(u.columnsState) || JSON.stringify(b.style) !== JSON.stringify(u.style)));
  return { FilterComponent: Se, FilterGroup: V, RowComponent: he };
};
function bt(e) {
  const { ElementTypes: g, THEME: f, BaseComponent: q, BaseConfiguration: K, getDefaultProps: ee, useComponentContext: Se } = e;
  _e && _e(e);
  const oe = e.getPlatformHooks(), V = {
    ...oe,
    // platform injected deps
    ...C
  }, { React: he } = V, {
    useEffect: b,
    useState: u,
    useMemo: L,
    useRef: v,
    useCallback: D
  } = he, X = () => ({ ...oe, ...C }), { FilterComponent: te, FilterGroup: se, RowComponent: re } = pt(V), { useExecuteFlow: G, evaluateFormula: le } = V, F = mt(g, f, K, ee), ne = F.defaultProps, _ = (a) => {
    const [n, m] = u(!1);
    b(() => {
      dt(() => e).then(() => m(!0));
    }, []);
    const { id: i, grid: k, properties: O, meta: W, updateProperties: N, onFxChange: A, ...s } = a;
    let { selectionBg: r, checkboxBorderColor: B, data: p = [], margin: E, border: xe, header_bg: ce, header_font_color: ye, checkbox_accent_col: we, onRowSelect: M, selected_row: I, selection_type: z, columns: y, primary_key: Re, border_radius: me, defaultSelected: Y, defaultSelectedFilter: Z } = { ...ne, ...O };
    const [S, pe] = u(null), [H, Ee] = u([]), { Drawer: Ge, Popover: ge, ArrowUpOutlined: We, ArrowDownOutlined: Je, AiOutlineCaretDown: Ue, AiOutlineCaretUp: Me, FaFilter: ve, TableList: Ie, AutoSizer: He } = X() || {}, [qe, Ae] = u(!1), [Te, De] = u(null), [w, ke] = u([]), [gt, ft] = u(null), [Fe, Ke] = u(!0);
    let [J, Le] = u([{ accessor: "", header: "" }]);
    L(() => y, [y]);
    const Ce = v(!1), [U, Be] = u(!1), Oe = D((t) => {
      var x;
      if (console.log("🔍 [Table] applyDefaultSelection called:", {
        defaultSelected: Y,
        tableDataLength: t.length,
        currentSelectedRow: !!S,
        defaultSelectionApplied: U,
        tableDataFirstKey: (x = t[0]) == null ? void 0 : x.key
      }), !Y || Y === "none" || t.length === 0) {
        console.log("🔍 [Table] Skipping default selection: no selection type or no data");
        return;
      }
      if (U || S) {
        console.log("🔍 [Table] Skipping default selection: already applied or row selected");
        return;
      }
      let l = null;
      switch (Y) {
        case "first":
          l = t[0], console.log("🎯 [Table] Selecting first row:", l == null ? void 0 : l.key);
          break;
        case "last":
          l = t[t.length - 1], console.log("🎯 [Table] Selecting last row:", l == null ? void 0 : l.key);
          break;
        case "filter":
          Z && typeof Z == "object" ? (l = t.find((h) => Object.entries(Z).every(([R, d]) => h[R] === void 0 ? !1 : typeof d == "string" && typeof h[R] == "string" ? h[R].toLowerCase().includes(d.toLowerCase()) : h[R] === d)) || null, console.log("🎯 [Table] Filter result:", l == null ? void 0 : l.key, "with filter:", Z)) : console.log("🔍 [Table] No valid filter provided for filter selection");
          break;
      }
      l ? (console.log("🎯 [Table] Applying default selection:", l), console.log("🎯 [Table] Before setting - selectedRow:", S, "selected_row prop:", I), pe(l), Be(!0), M == null || M(l), N(i, "selected_row", l), console.log("🎯 [Table] After setting - targetRow:", l)) : console.log("🔍 [Table] No target row found for default selection");
    }, [Y, Z, M, N, i, U]), [ie, $e] = u([]);
    b(() => {
      console.log("🔄 [Table] Default selection properties changed, resetting flag"), Be(!1);
    }, [Y, Z]), b(() => {
      w.length > 0 && !U && !S && (console.log("🔄 [Table] Properties changed, applying default selection"), setTimeout(() => Oe(w), 100));
    }, [Y, Z, w, U, Oe, S]), b(() => {
      if (console.log("🔄 [Table] Columns configuration changed:", {
        columnsLength: y == null ? void 0 : y.length,
        tableDataLength: w.length,
        columnNames: y == null ? void 0 : y.map((t) => t.columnName),
        currentColumnsState: J.map((t) => t.accessor)
      }), y && Array.isArray(y) && y.length > 0 && w.length > 0) {
        const t = y.map((c) => c.columnName), l = Object.keys(w[0] || {}).filter((c) => c !== "key" && c !== Re);
        console.log("🔍 [Table] Available data columns:", l), console.log("🔍 [Table] Ordered column names from config:", t);
        const x = t.filter((c) => l.includes(c)), h = l.filter((c) => !t.includes(c)), R = [...x, ...h];
        console.log("🔍 [Table] Final column order:", R);
        const d = R.map((c, P) => ({
          header: c,
          accessor: c,
          type: w[0]
        }));
        Le(d), console.log("🔄 [Table] Columns FORCE reordered:", {
          configOrder: t,
          finalOrder: d.map((c) => c.header),
          timestamp: Date.now()
        });
      }
    }, [y, w, Re]), b(() => {
      console.log("🔄 [Table] Selected row prop sync - selected_row:", I, "selectedRow:", S, "defaultSelectionApplied:", U), !U && I && JSON.stringify(I) !== JSON.stringify(S) ? (console.log("🔄 [Table] Syncing selected_row prop to internal state:", I), pe(I)) : !I && S && !U ? (console.log("🔄 [Table] Clearing selected row"), pe(null)) : console.log("🔄 [Table] No sync needed - conditions not met");
    }, [I, S, U]);
    const Ve = (t) => {
      De(t), Ae(!0);
    }, Xe = () => {
      Ae(!1), De(null);
    };
    p = p || [];
    const Ye = (t) => {
      if (typeof t == "number") return "Number";
      if (typeof t == "boolean") return "Boolean";
      if (typeof t == "string") {
        if (t.includes("@") && t.includes(".")) return "Email";
        if (t.startsWith("http://") || t.startsWith("https://")) return "Url";
        const l = Date.parse(t);
        if (!isNaN(l)) return "Date";
        try {
          const x = JSON.parse(t);
          if (Array.isArray(x)) return "MultiSelect";
          if (typeof x == "object" && x !== null) return "Json";
        } catch {
          return "Text";
        }
      }
      return Array.isArray(t) ? "MultiSelect" : typeof t == "object" && t !== null ? "Json" : "Text";
    }, [de, Ze] = u({
      key: null,
      direction: null
    }), Qe = (t, l) => {
      Ze({ key: t, direction: l });
      const x = [...w].sort((h, R) => {
        const d = h[t] ?? "", c = R[t] ?? "";
        return typeof d == "number" && typeof c == "number" ? l === "asc" ? d - c : c - d : l === "asc" ? String(d).localeCompare(String(c)) : String(c).localeCompare(String(d));
      });
      ke(x), $e(x);
    }, et = (t, l, x) => /* @__PURE__ */ e.React.createElement("div", { className: "rounded-sm w-full h-full flex flex-col gap-2 " }, /* @__PURE__ */ e.React.createElement(
      "button",
      {
        onClick: () => x(t.accessor, "asc"),
        className: `group w-full flex items-start flex-start p-[5px] rounded-md transition font-sans font-semibold tracking-wide 
                    ${l.key === t.accessor && l.direction === "asc" ? "bg-gray-200 text-black" : ""} 
                    group-bg-gray-200 hover:text-black`
      },
      /* @__PURE__ */ e.React.createElement(We, { className: `text-[17px] pr-2 transition  ${l.key === t.accessor && l.direction === "asc" ? "text-black" : "text-gray-400"} group-hover:text-black` }),
      /* @__PURE__ */ e.React.createElement("span", { className: "text-gray-600 group-hover:text-black" }, "Sort Ascending")
    ), /* @__PURE__ */ e.React.createElement(
      "button",
      {
        onClick: () => x(t.accessor, "desc"),
        className: `group w-full flex items-start  p-[5px] flex-start rounded-md transition font-sans font-semibold tracking-wide
                        ${l.key === t.accessor && l.direction === "desc" ? "bg-gray-200 text-black" : ""} 
                        group-bg-gray-200 hover:text-black`
      },
      /* @__PURE__ */ e.React.createElement(
        Je,
        {
          className: `text-[17px] transition pr-2
                            ${l.key === t.accessor && l.direction === "desc" ? "text-black" : "text-gray-400"} 
                            group-hover:text-black`
        }
      ),
      /* @__PURE__ */ e.React.createElement("span", { className: "text-gray-600 group-hover:text-black" }, "Sort Descending")
    )), tt = L(() => n ? (console.log("render 123= header"), /* @__PURE__ */ e.React.createElement("tr", { style: { backgroundColor: ce, color: ye } }, z === "multiple" && /* @__PURE__ */ e.React.createElement("th", { style: { padding: "15px" } }, z === "multiple" ? /* @__PURE__ */ e.React.createElement(
      "input",
      {
        type: "checkbox",
        checked: H.length === w.length && w.length > 0,
        onChange: (t) => {
          t.stopPropagation(), t.target.checked ? Ee([...w]) : Ee([]);
        },
        style: {
          appearance: "none",
          width: "18px",
          height: "18px",
          borderRadius: "6px",
          border: `1px solid ${B}`,
          // border: `2px solid ${checkbox_accent_col}`,
          backgroundColor: H.length === w.length && w.length > 0 ? we : "transparent",
          // Gray when checked
          transition: "all 0.2s ease-in-out",
          display: "flex",
          alignItems: "center",
          justifyContent: "center",
          position: "relative",
          visibility: H.length > 0 ? "visible" : "hidden"
        }
      }
    ) : null), /* @__PURE__ */ e.React.createElement("th", { style: { padding: "5px 15px", minWidth: "110px", maxWidth: "110px", textAlign: "start" } }, /* @__PURE__ */ e.React.createElement("span", { className: "font-sans font-semibold tracking-wide", style: { cursor: "pointer", fontSize: "medium", color: "#555870" } })), J.map((t) => /* @__PURE__ */ e.React.createElement("th", { key: t.accessor, style: { padding: "8px 15px", paddingLeft: "5px", minWidth: "160px", maxWidth: "160px", textAlign: "start" } }, /* @__PURE__ */ e.React.createElement("div", { className: "flex items-center justify-start h-7" }, /* @__PURE__ */ e.React.createElement("div", { className: "group hover:bg-gray-200 group-hover:text-black transition font-sans font-semibold tracking-wide rounded-md cursor-pointer flex items-center gap-2  px-2 h-full ", style: { fontSize: "medium", color: "#555870" } }, t.header, /* @__PURE__ */ e.React.createElement(
      ge,
      {
        content: et(t, de, Qe),
        trigger: "click",
        placement: "bottom"
      },
      /* @__PURE__ */ e.React.createElement("div", { className: "flex flex-col items-center h-5" }, /* @__PURE__ */ e.React.createElement(Me, { className: `text-[13px] ${de.key === t.accessor && de.direction === "asc" ? "text-black" : "text-gray-400"} group-hover:text-black` }), /* @__PURE__ */ e.React.createElement(Ue, { className: `text-[13px] ${de.key === t.accessor && de.direction === "desc" ? "text-black" : "text-gray-400"} group-hover:text-black` }))
    ))))))) : null, [w, H, z, n]), rt = D((t, l) => {
      const x = (h) => h ? new Date(h).toLocaleDateString("en-US", { month: "short", day: "2-digit", year: "numeric" }) : "";
      switch (l) {
        case "Email":
          return /* @__PURE__ */ e.React.createElement("a", { href: `mailto:${t}`, style: { color: "#2563EB" } }, t);
        case "Url":
          return /* @__PURE__ */ e.React.createElement("a", { href: t, target: "_blank", rel: "noopener noreferrer", style: { color: "#2563EB" } }, t);
        case "Number":
        case "Boolean":
          return /* @__PURE__ */ e.React.createElement("span", { style: { color: "#2563EB" } }, t);
        case "Date":
        case "DOB":
          return x(t);
        case "Json":
          try {
            const d = typeof t == "string" ? JSON.parse(t) : t;
            return JSON.stringify(d);
          } catch {
            return t;
          }
        case "Text":
          return t;
        case "MultiSelect":
          const h = ["#FFEFD5", "#FFDAB9", "#E6E6FA", "#D3F8E2", "#F5E6CC", "#D0E2FF", "#FFDFD3"], R = Array.isArray(t) ? t.map((d) => typeof d == "object" ? JSON.stringify(d) ?? "N/A" : d).filter((d) => typeof d == "string" && d.trim() !== "") : [];
          return R.length > 0 ? /* @__PURE__ */ e.React.createElement("div", { style: { display: "flex", flexWrap: "nowrap", gap: "5px", alignItems: "center" } }, R.slice(0, 2).map((d, c) => /* @__PURE__ */ e.React.createElement(
            ge,
            {
              content: /* @__PURE__ */ e.React.createElement("div", { key: c, style: {
                backgroundColor: h[c % h.length],
                padding: "2px 6px",
                borderRadius: "5px",
                fontSize: "12px",
                color: "black",
                fontWeight: "300",
                display: "inline-block"
              } }, d),
              trigger: "hover",
              placement: "top"
            },
            /* @__PURE__ */ e.React.createElement("div", { key: c, style: {
              backgroundColor: h[c % h.length],
              padding: "2px 6px",
              borderRadius: "5px",
              fontSize: "10px",
              color: "black",
              fontWeight: "300",
              display: "inline-block"
            } }, d.substring(0, 10) + "..")
          )), R.length > 1 && /* @__PURE__ */ e.React.createElement(
            ge,
            {
              content: /* @__PURE__ */ e.React.createElement("div", { style: {
                display: "grid",
                gridTemplateColumns: "repeat(auto-fit, minmax(70px, 1fr))",
                gap: "4px",
                maxWidth: "220px",
                background: "white",
                borderRadius: "8px"
              } }, R.slice(2).map((d, c) => /* @__PURE__ */ e.React.createElement("div", { key: c, style: {
                backgroundColor: h[(c + 2) % h.length],
                // Keep color pattern
                padding: "3px 5px",
                borderRadius: "6px",
                fontSize: "14px",
                color: "black",
                fontWeight: "300",
                textAlign: "center"
              } }, d))),
              trigger: "hover",
              placement: "top"
            },
            /* @__PURE__ */ e.React.createElement("div", { style: {
              cursor: "pointer",
              color: "#888",
              fontSize: "12px",
              paddingLeft: "5px"
            } }, "+", R.length - 2)
          )) : "N/A";
        // Default fallback when value is empty or not an array
        default:
          return t;
      }
    }, []), je = D((t, l) => rt(t, l), [y]), lt = D((t, l) => {
      console.log("Row clicked:", t, "Current selectedRow:", S), z === "single" ? (!S || S.key !== t.key) && (console.log("Updating selected row to:", t), pe(t), M == null || M(t), N(i, "selected_row", t)) : z === "multiple" && Ee((x) => {
        const h = t.key;
        if (new Set(x.map((d) => d.key)).has(h)) {
          const d = x.filter((c) => c.key !== h);
          return N(i, "selected_rows", d), d;
        } else {
          const d = [...x, t];
          return N(i, "selected_rows", d), d;
        }
      });
    }, [z, i, M, N, S]), nt = ({ index: t, style: l }) => {
      const x = w[t], h = z === "single" ? (S == null ? void 0 : S.key) === x.key : H.some((R) => R.key === x.key);
      return (
        // <div style={{ ...style, display: 'table-row' }} key={`${row.key || index}-${JSON.stringify(columns)}`}>
        /* @__PURE__ */ e.React.createElement(
          re,
          {
            row: x,
            index: t,
            isSelected: h,
            columns: y,
            columnsState: J,
            selectionType: z,
            handleRowClick: lt,
            checkboxBorderColor: B,
            checkboxAccentCol: we,
            selectionBg: r,
            renderCell: je,
            showDrawer: Ve,
            style: l
          }
        )
      );
    }, at = L(() => n ? !Array.isArray(w) || w.length === 0 ? /* @__PURE__ */ e.React.createElement("tr", { style: { maxHeight: "50px" } }, /* @__PURE__ */ e.React.createElement("td", { colSpan: J.length + (z ? 1 : 0) }, "No data found")) : (console.log("render 123= renderBody"), /* @__PURE__ */ e.React.createElement(He, null, ({ height: t, width: l }) => /* @__PURE__ */ e.React.createElement(
      Ie,
      {
        width: l,
        height: t,
        itemCount: w.length,
        itemSize: 50
      },
      ({ index: x, style: h }) => /* @__PURE__ */ e.React.createElement(nt, { index: x, style: h })
    ))) : null, [w, S, H, z, y, B, we, r, n]), ot = {
      id: i,
      properties: O,
      meta: W,
      EditProperties: j,
      updateProperties: N,
      grid: k,
      Configuration: $
    };
    b(() => {
      var x;
      if (console.log("🔍 [Table] useEffect triggered with data:", {
        hasData: !!p,
        dataLength: (p == null ? void 0 : p.length) || "N/A",
        dataKeys: p && p.length > 0 ? Object.keys(p[0]) : "N/A",
        tableHasRunOnce: Ce.current,
        dataStringified: ((x = JSON.stringify(p)) == null ? void 0 : x.substring(0, 100)) + "..."
      }), Ce.current && JSON.stringify(p) === JSON.stringify(ie)) {
        console.log("🔍 [Table] Skipping update - data unchanged");
        return;
      }
      Ce.current = !0;
      const t = performance.now();
      async function l() {
        console.log("render 123 table");
        const h = p.length > 0 ? Object.keys(p[0]) : [], R = h.find((c) => c.toLowerCase().includes("id")) || h.find((c) => c.toLowerCase().includes("_id")) || h[0];
        if (console.log("Primary Key Determined:", R), j[2].elements[0] = {
          label: "primary_key",
          name: "primary_key",
          type: g.SELECT(h, R),
          width: 24
        }, p && Object.keys(p).length > 0) {
          const c = Object.values(p).map((P) => ({
            ...P,
            key: P[R]
            // Set its value as the key
          }));
          performance.now(), ke(() => c), $e(() => c), setTimeout(() => {
            S ? console.log("🔍 [Table] Skipping default selection - row already selected") : Oe(c);
          }, 100), N(i, "value", p), N(i, "data", p);
        }
        if (Ke(!1), console.log("evaluatedvalue===", p), p.length > 0) {
          const c = Object.keys(p[0]).filter((T) => T !== "key" && T !== Re);
          console.log("📊 [Table] Data useEffect - Available data columns:", c), console.log("📊 [Table] Data useEffect - Current columns config:", y == null ? void 0 : y.map((T) => T.columnName)), console.log("📊 [Table] Data useEffect - Current columnsState:", J.map((T) => T.accessor));
          let P = c;
          if (y && Array.isArray(y) && y.length > 0) {
            const T = y.map((ae) => ae.columnName).filter((ae) => c.includes(ae)), Q = c.filter(
              (ae) => !y.some((it) => it.columnName === ae)
            );
            P = [...T, ...Q], console.log("📊 [Table] Data useEffect - Ordered columns from config:", P);
          }
          const ue = J.map((T) => T.accessor).filter(Boolean), Ne = P, fe = J.length === 0 || J[0].accessor === "";
          if (console.log("📊 [Table] Data useEffect - Update decision:", {
            currentColumnOrder: ue,
            expectedOrder: Ne,
            isUninitialized: fe,
            willUpdate: fe,
            skipReason: fe ? "none" : "columns already initialized"
          }), fe) {
            const T = P.map((Q, ae) => ({
              header: Q,
              accessor: Q,
              type: p[0]
            }));
            Le(() => T), console.log("🔄 [Table] Columns INITIALIZED from data:", T.map((Q) => Q.header));
          }
          const ct = P.map((T, Q) => ({
            columnName: T,
            columnType: Ye(p[0][T]) || "Text"
          }));
          N(i, "columns", [...ct]);
        }
        const d = performance.now();
        console.log(`Total useEffect execution time: ${(d - t).toFixed(2)} ms`);
      }
      console.log("table rerender"), l();
    }, [p]), b(() => {
      console.log("render 123 columns");
    }, [y]);
    let st = w && ie && Array.isArray(w) && Array.isArray(ie) && w.length !== ie.length;
    return n ? /* @__PURE__ */ e.React.createElement(
      q,
      {
        ...ot,
        style: {
          display: "flex",
          flexDirection: "column",
          overflow: "hidden"
        }
      },
      /* @__PURE__ */ e.React.createElement(
        "div",
        {
          className: "tableWrap",
          style: {
            flex: "1 1 auto",
            overflowY: "auto",
            overflowX: "auto",
            maxHeight: "100%",
            margin: `${E[0]} ${E[1]} 0 ${E[3]}`,
            // marginBottom: selectedRows.length > 0 ? 0 : margin[2],
            borderRadius: `${me[0]} ${me[1]} 0 0`
            // paddingBottom: '40px', // Add padding equal to the height of the bottom div
          }
        },
        /* @__PURE__ */ e.React.createElement(
          "table",
          {
            style: {
              width: "100%",
              borderCollapse: "collapse",
              height: "100%",
              maxHeight: "100%"
            }
          },
          Fe ? /* @__PURE__ */ e.React.createElement("div", { className: "flex items-center justify-center h-full w-full" }, /* @__PURE__ */ e.React.createElement("img", { style: { height: "15%", width: "15%" }, src: "/images/loading.gif", alt: "loading..." })) : /* @__PURE__ */ e.React.createElement(e.React.Fragment, null, /* @__PURE__ */ e.React.createElement("thead", null, tt), /* @__PURE__ */ e.React.createElement("tbody", null, at))
        )
      ),
      /* @__PURE__ */ e.React.createElement(
        "div",
        {
          className: "relative flex items-center  bg-gray-100  rounded-b-lg",
          style: {
            flex: "0 0 auto",
            margin: `0 ${E[1]} ${E[2]} ${E[3]}`,
            borderRadius: `0 0 ${me[2]} ${me[3]}`,
            width: `calc(100% - (${E[1]} + ${E[3]}))`,
            padding: "10px"
          }
        },
        /* @__PURE__ */ e.React.createElement("span", { className: "absolute left-1/2 transform -translate-x-1/2 text-gray-600" }, H.length > 0 ? `${H.length} out of ${w.length} selected` : `${w.length} Results`),
        !Fe && /* @__PURE__ */ e.React.createElement(
          ge,
          {
            trigger: "click",
            placement: "bottom",
            content: /* @__PURE__ */ e.React.createElement(te, { columns: y, tableData: w, originalData: ie, setTableData: ke })
          },
          st ? /* @__PURE__ */ e.React.createElement(ve, { className: "ml-auto text-blue-400 text-sm cursor-pointer hover:text-blue-800" }) : /* @__PURE__ */ e.React.createElement(ve, { className: "ml-auto text-gray-400 text-sm cursor-pointer hover:text-gray-800" })
        )
      ),
      /* @__PURE__ */ e.React.createElement(Ge, { title: "User Profile", width: 840, placement: "right", onClose: Xe, open: qe }, Te ? /* @__PURE__ */ e.React.createElement("div", { style: { padding: "8px" } }, J.map(({ header: t, accessor: l }, x) => {
        let h = Te[l];
        const R = (d) => {
          if (typeof d == "object" && d !== null)
            return Object.entries(d).map(([ue, Ne]) => `${ue}: ${R(Ne)}`).join(", ");
          let c = y.find((ue) => ue.columnName === l);
          return c || console.warn(`Column not found for columnName: ${l}`), `${x}${c.accessor}`, je(d, c.columnType);
        };
        return /* @__PURE__ */ e.React.createElement("div", { key: l, style: { marginBottom: "0px", padding: "5px" } }, l === "image" ? /* @__PURE__ */ e.React.createElement("div", null, /* @__PURE__ */ e.React.createElement("strong", null, t), /* @__PURE__ */ e.React.createElement("br", null), /* @__PURE__ */ e.React.createElement(
          "img",
          {
            src: h,
            alt: "Profile",
            style: { width: "100px", borderRadius: "8px", marginTop: "5px", boxShadow: "0 1px 2px rgba(0,0,0,0.1)" }
          }
        )) : /* @__PURE__ */ e.React.createElement("p", { style: { margin: "0" } }, /* @__PURE__ */ e.React.createElement("strong", { style: { display: "block", marginBottom: "5px" } }, t), /* @__PURE__ */ e.React.createElement("p", { style: { color: "#898585" } }, R(h))), /* @__PURE__ */ e.React.createElement("hr", { style: { border: "1px solid #f7f7f7", margin: "8px 0" } }));
      })) : /* @__PURE__ */ e.React.createElement("p", { style: { padding: "16px" } }, "No profile data")),
      /* @__PURE__ */ e.React.createElement("style", null, `


                .tableWrap {
                    height: 100%;
                    border: ${xe};
                    overflow: auto;
                }
                
                tbody{
                max-height:100%
                display: block
                }
        
                thead tr {
                    background-color: ${ce};
                    color: ${ye};
                    
                }
                
            tbody td{
            td {
                height: 8px; 
                overflow: hidden; 
                padding: 0; 
                white-space: nowrap;
                }
            }
        
                thead tr th {
                    padding: 10px;
                    border-bottom: 2px solid #ddd;
                    position: sticky;
                    top: 0;
                }
                
                tbody tr td {
                padding:10px
                }
        
                table {
                    border-collapse: collapse;
                }
        
                th {
                    padding: 16px;
                    border-bottom: 1px solid #e8e8e8;
                    background: ${ce};
                    color: ${ye};
                    box-shadow: 0px 0px 0 2px #e8e8e8;
                }
            `)
    ) : null;
  }, j = Pe(g, f), $ = ze(K);
  return _.EditProperties = j, _.PropsList = Object.keys(j), _.properties = ee(j), _.Configuration = $, {
    component: (a) => /* @__PURE__ */ e.React.createElement(
      _,
      {
        ...a,
        EditProperties: F.EditProperties,
        Configuration: F.Configuration
      }
    ),
    manifest: F
  };
}
export {
  bt as createComponent,
  C as runtimeDeps
};
