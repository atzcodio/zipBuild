import * as ProductCmp from "./../static/js/components/productinfo.es.js";
import * as ButtonCmp from "./../static/js/components/button.es.js";
import * as ImageCmp from "./../static/js/components/image.es.js";
import * as Table from "./../static/js/components/table.es.js";
window.LowcodePlatform.registerComponent("ProductInfo", ProductCmp);
window.LowcodePlatform.registerComponent("Button", ButtonCmp);
window.LowcodePlatform.registerComponent("Image", ImageCmp);
window.LowcodePlatform.registerComponent("Table", TableCmp);

