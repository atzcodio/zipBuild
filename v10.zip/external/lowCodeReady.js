window.addEventListener("lowcode-platform-ready",()=>{
    console.log("Lowcode ready")
});