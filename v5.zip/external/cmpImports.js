import * as ProductCmp from "./../static/js/components/productinfo.es.js"; 
// import * as ButtonCmp from "/static/js/components/button.es.js"; 
window.LowcodePlatform.registerComponent("ProductInfo", ProductCmp);
// window.LowcodePlatform.registerComponent("Button", ButtonCmp);